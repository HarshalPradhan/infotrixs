package com.infotrix.ems.dao;

import java.util.List;

import com.infotrix.ems.pojo.Employee;


public interface IEmployeeDao {
	
	public int addEmployee(Employee emp);
	
	public int updateEmployee(Employee emp);
	
	public int deleteEmployee(int empId);
	
	public Employee searchEmployeeById(int empId);
	
	public Employee searchEmployeeByName(String empName);
	
	public List<Employee> selectAllEmployee();
	

}
