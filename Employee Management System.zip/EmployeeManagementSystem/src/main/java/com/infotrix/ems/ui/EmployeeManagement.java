package com.infotrix.ems.ui;

import java.util.List;
import java.util.Scanner;

import com.infotrix.ems.exceptions.AdminNotFoundException;
import com.infotrix.ems.pojo.Employee;
import com.infotrix.ems.service.IServiceEmployee;
import com.infotrix.ems.service.ServiceEmployeeImp;

public class EmployeeManagement {

	public static void main(String[] args) {

		Scanner in = new Scanner(System.in);

		IServiceEmployee service1 = new ServiceEmployeeImp();

		// Admin Login
		System.out.println("**Admin Login**");
		System.out.println("Enter Admin Name: ");
		String adminName = in.next();
		System.out.println("Enter your Password: ");
		String adminPassword = in.next();

		if (adminName.equals("Harshal") && adminPassword.equals("Harshal@123")) {
			System.out.println("You are successfully logged in...");

			boolean flag = true;

			while (flag) {
				System.out.println("1. Add Employee");
				System.out.println("2. Update Employee");
				System.out.println("3. Delete Employee");
				System.out.println("4. Search Employee");
				System.out.println("5. Select All Employee");
				System.out.println("0. Exit");

				System.out.println("Enter Your Choice...");

				int choice = in.nextInt();

				switch (choice) {
				case 1:
					// add menu
					System.out.println("**Add Employee**");
					System.out.println("Enter employee Id: ");
					int empId = in.nextInt();
					System.out.println("Enter Employee Name: ");
					String empName = in.next();
					System.out.println("Enter email: ");
					String email = in.next();
					System.out.println("Enter address: ");
					String address = in.next();
					System.out.println("Enter Contact No:");
					long ContactNo = in.nextLong();

					Employee emp = new Employee();

					emp.setEmpId(empId);
					emp.setEmpName(empName);
					emp.setEmail(email);
					emp.setAddress(address);
					emp.setContactNo(ContactNo);
					

					int count1 = service1.addEmployee(emp);

					if (count1 > 0) {
						System.out.println(count1 + " Employee Added Successfully ");

					} else {
						System.out.println("Add Failed");
					}

					break;

				case 2:

					// update menu

					System.out.println("**Update Employee**");

					System.out.println("Enter Employee Id: ");
					int empId1 = in.nextInt();
					System.out.println("Enter Employee Name: ");
					String empName1 = in.next();
					System.out.println("Enter email: ");
					String email1 = in.next();
					System.out.println("Enter address: ");
					String address1 = in.next();
					System.out.println("Enter contact No. : ");
					long contactNo1 = in.nextLong();

					Employee emp1 = new Employee();
					
					emp1.setEmpId(empId1);
					emp1.setEmpName(empName1);
					emp1.setEmail(email1);
					emp1.setAddress(address1);
					emp1.setContactNo(contactNo1);


					int count2 = service1.updateEmployee(emp1);

					if (count2 > 0) {
						System.out.println(count2 + " Employee Updated Successfully ");

					} else {
						System.out.println("Update Failed");
					}
					break;

				// delete Employee from Employee table
				case 3:
					System.out.println("**Delete Employee**");

					System.out.println("Enter Employee Id to Delete Employee : ");

					int empId2 = in.nextInt();

					int n1 = service1.deleteEmployee(empId2);

					if (n1 > 0) {

						System.out.println(n1 + " Employee Deleted Successfully");

					} else {

						System.err.println("Delete Failed...");
					}
					break;

				case 4:

					// search Employee
					System.out.println("Enter Id to Search Employee");

					int empId3 = in.nextInt();

					Employee search = service1.searchEmployeeById(empId3);

					if (search != null) {

						System.out.println(search);

					} else {

						System.err.println("Employee Not Found");
					}
					break;

				case 5:

					// select all Employee
					List<Employee> empList = service1.selectAllEmployee();

					for (Employee employee : empList) {

						System.out.println(employee);
					}
					break;

				case 0:
					// exit
					flag = false;
					System.err.println("You are exit");
					break;

				default:
					System.out.println("wrong choice...enter again");
					break;
				}

			}

		} else {
			try {
				throw new AdminNotFoundException();
			} catch (AdminNotFoundException e) {
				e.printStackTrace();
				System.out.println("Login failed");
			}
		}

	}

}
