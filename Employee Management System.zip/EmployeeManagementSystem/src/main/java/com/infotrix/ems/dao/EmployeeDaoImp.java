package com.infotrix.ems.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.infotrix.ems.pojo.Employee;


public class EmployeeDaoImp implements IEmployeeDao {
	
	Connection conn = DBFactory.getDBConnection();
	PreparedStatement pstmt;
	
	

	@Override
	public int addEmployee(Employee emp) {
		
		
		String insertQuery = "insert into employee(id, name, email, address, mobNo) value(?,?,?,?,?)";
		int count = 0;

		try {
			pstmt = conn.prepareStatement(insertQuery);
			
			pstmt.setInt(1, emp.getEmpId());
			pstmt.setString(2, emp.getEmpName());
			pstmt.setString(3, emp.getEmail());
			pstmt.setString(4, emp.getAddress());
			pstmt.setLong(5, emp.getContactNo());

			
			count = pstmt.executeUpdate();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return count;
	}

	@Override
	public int updateEmployee(Employee emp) {
		String insertQuery = "update employee set name = ?, email = ?, address=?, mobNo=? where id = ?";
		int count = 0;

		try {
			pstmt = conn.prepareStatement(insertQuery);
			
			
			pstmt.setString(1, emp.getEmpName());
			pstmt.setString(2, emp.getEmail());
			pstmt.setString(3, emp.getAddress());
			pstmt.setLong(4, emp.getContactNo());
			pstmt.setInt(5, emp.getEmpId());

			
			count = pstmt.executeUpdate();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return count;
	}

	@Override
	public int deleteEmployee(int empId) {
		String deleteQuery = "delete from employee where id = ?";
		int count = 0;

		try {
			pstmt = conn.prepareStatement(deleteQuery);

			pstmt.setInt(1, empId);

			count = pstmt.executeUpdate();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return count;
		
	}

	@Override
	public Employee searchEmployeeById(int empId) {
		String searchQuery = "select * from employee where id = ?";
		int count = 0;

		Employee emp = new Employee();

		try {

			pstmt = conn.prepareStatement(searchQuery);

			pstmt.setInt(1, empId);

			ResultSet rs = pstmt.executeQuery();

			while (rs.next()) {
				
				int empId1 = rs.getInt("id");
				String name = rs.getString("name");
				String email = rs.getString("email");
				String address = rs.getString("address");
				Long mobNo = rs.getLong("mobNo");
				
				emp.setEmpId(empId1);
				emp.setEmpName(name);
				emp.setEmail(email);
				emp.setAddress(address);
				emp.setContactNo(mobNo);


			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return emp;
	}

	@Override
	public List<Employee> selectAllEmployee() {
		List<Employee> empList = null;

		try {

			String selectAllQuery = "select * from employee";

			pstmt = conn.prepareStatement(selectAllQuery);

			ResultSet rs = pstmt.executeQuery();

			empList = new ArrayList<Employee>();

			while (rs.next()) {

				int empId = rs.getInt("id");
				String empName = rs.getString("name");
				String email = rs.getString("email");
				String address = rs.getString("address");
				Long mobNo = rs.getLong("mobNo");

				Employee emp = new Employee();
				
				emp.setEmpId(empId);
				emp.setEmpName(empName);
				emp.setEmail(email);
				emp.setAddress(address);
				emp.setContactNo(mobNo);
				

				empList.add(emp);

			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return empList;
	}

	@Override
	public Employee searchEmployeeByName(String empName) {
		
		String searchQuery = "select * from employee where name = ?";
		int count = 0;

		Employee emp = new Employee();

		try {

			pstmt = conn.prepareStatement(searchQuery);

			pstmt.setString(1, empName);

			ResultSet rs = pstmt.executeQuery();

			while (rs.next()) {
				
				int empId = rs.getInt("id");
				String empName1 = rs.getString("name");
				String email = rs.getString("email");
				String address = rs.getString("address");
				Long mobNo = rs.getLong("mobNo");
				
				emp.setEmpId(empId);
				emp.setEmpName(empName1);
				emp.setEmail(email);
				emp.setAddress(address);
				emp.setContactNo(mobNo);


			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return emp;
		
		
	}

}
