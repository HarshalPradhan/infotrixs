package com.infotrix.ems.service;

import java.util.List;

import com.infotrix.ems.dao.EmployeeDaoImp;
import com.infotrix.ems.dao.IEmployeeDao;
import com.infotrix.ems.pojo.Employee;


public class ServiceEmployeeImp implements IServiceEmployee {

	IEmployeeDao dao = null;

	public ServiceEmployeeImp() {

		dao = new EmployeeDaoImp();

	}

	@Override
	public int addEmployee(Employee emp) {

		return dao.addEmployee(emp);
	}

	@Override
	public int updateEmployee(Employee emp) {

		return dao.updateEmployee(emp);
	}

	@Override
	public int deleteEmployee(int empId) {
		// TODO Auto-generated method stub
		return dao.deleteEmployee(empId);
	}

	@Override
	public Employee searchEmployeeById(int empId) {
		// TODO Auto-generated method stub
		return dao.searchEmployeeById(empId);
	}

	@Override
	public List<Employee> selectAllEmployee() {
		// TODO Auto-generated method stub
		return dao.selectAllEmployee();
	}

	@Override
	public Employee searchEmployeeByName(String empName) {
		// TODO Auto-generated method stub
		return dao.searchEmployeeByName(empName);
	}

}
