package com.infotrix.ems.exceptions;

public class AdminNotFoundException extends RuntimeException{

}
