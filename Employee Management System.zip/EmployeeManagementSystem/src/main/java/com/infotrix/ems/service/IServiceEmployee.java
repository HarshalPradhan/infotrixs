package com.infotrix.ems.service;

import java.util.List;

import com.infotrix.ems.pojo.Employee;


public interface IServiceEmployee {

	public int addEmployee(Employee emp); // add Employee by admin

	public int updateEmployee(Employee emp); // update Employee by admin

	public int deleteEmployee(int empId); // delete Employee by admin

	public Employee searchEmployeeById(int empId); // search Employee

	public List<Employee> selectAllEmployee();	// select Employee

	public Employee searchEmployeeByName(String empName); // search Employee by item

}
